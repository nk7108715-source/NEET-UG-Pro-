package com.neetugpro.student;

final class AdPolicy {
    static final long MIN_GAP_MS = 120_000;
    private AdPolicy() {}
    static boolean frequencyAllowed(long nowWall, long lastWall, long nowElapsed, long lastElapsed) {
        if (lastWall == 0) return true;
        // Wall time survives restarts; monotonic time protects against in-session clock edits.
        if (nowWall - lastWall < MIN_GAP_MS) return false;
        return nowElapsed < lastElapsed || nowElapsed - lastElapsed >= MIN_GAP_MS;
    }
}
