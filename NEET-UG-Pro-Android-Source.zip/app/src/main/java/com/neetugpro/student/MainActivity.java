package com.neetugpro.student;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Demo ad IDs only. Production consent and release signing are separate steps. */
public final class MainActivity extends Activity {
    private static final String ORIGIN = "https://nk7108715-source.github.io";
    private static final String PATH = "/NEET-UG-Pro-/";
    private static final String START_URL = ORIGIN + PATH;
    private static final String BANNER = "ca-app-pub-3940256099942544/9214589741";
    private static final String INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712";
    private WebView web;
    private LinearLayout bannerArea;
    private TextView status;
    private Button retry;
    private AdView banner;
    private InterstitialAd interstitial;
    private SharedPreferences prefs;
    private final Set<String> completedEvents = new HashSet<>();
    private boolean destroyed, resumed, sdkReady, loadingInterstitial, adShowing, pageFailed;
    private boolean bannerWanted, bannerLoaded;
    private String currentScreen = "loading";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("ad-frequency", MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets x = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(x.left, x.top, x.right, x.bottom);
            } else {
                v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        status = new TextView(this);
        status.setText("NEET UG Pro · TEST BUILD · Connecting…");
        status.setTextSize(11);
        status.setPadding(dp(10), dp(4), dp(10), dp(4));
        root.addView(status);
        retry = new Button(this);
        retry.setText("Retry connection");
        retry.setVisibility(View.GONE);
        retry.setOnClickListener(v -> web.loadUrl(START_URL));
        root.addView(retry);
        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        bannerArea = new LinearLayout(this);
        bannerArea.setOrientation(LinearLayout.VERTICAL);
        bannerArea.setGravity(Gravity.CENTER);
        bannerArea.setPadding(0, dp(8), 0, dp(8));
        bannerArea.setVisibility(View.GONE);
        root.addView(bannerArea);
        setContentView(root);
        root.requestApplyInsets();

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);

        // Origin-scoped, top-frame messaging; no addJavascriptInterface is exposed.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "NeetNative", Collections.singleton(ORIGIN),
                (view, message, source, mainFrame, reply) -> {
                    if (!mainFrame || !ORIGIN.equals(source.toString()) || !trusted(view.getUrl())) return;
                    receive(message.getData());
                });
        }
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setNegativeButton("Cancel", (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("OK", (d, w) -> result.confirm())
                    .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                if (trusted(request.getUrl().toString())) return false;
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
                }
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                currentScreen = "loading";
                pageFailed = false;
                bannerWanted = false;
                updateBanner();
                retry.setVisibility(View.GONE);
                status.setText("NEET UG Pro · TEST BUILD · Loading…");
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (!trusted(url) || pageFailed) return;
                status.setText("NEET UG Pro · TEST ADS ONLY");
                try {
                    String script;
                    try (java.io.InputStream input = getAssets().open("native-adapter.js")) {
                        java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
                        byte[] buffer = new byte[4096]; int n;
                        while ((n = input.read(buffer)) != -1) bytes.write(buffer, 0, n);
                        script = bytes.toString("UTF-8");
                    }
                    view.evaluateJavascript(script, null);
                } catch (Exception error) { status.setText("Website ready · ad adapter unavailable"); }
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (!request.isForMainFrame()) return;
                pageFailed = true;
                status.setText("Connection failed. Check internet, then retry.");
                retry.setVisibility(View.VISIBLE);
            }
        });
        if (Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
            android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::onBackPressed);
        web.loadUrl(START_URL);
        // Demo units only. Do not substitute production IDs in this test project.
        new Thread(() -> MobileAds.initialize(getApplicationContext(), result -> runOnUiThread(() -> {
            if (destroyed) return;
            sdkReady = true;
            loadBanner();
            loadInterstitial();
        }))).start();
    }

    static boolean trusted(String url) {
        if (url == null) return false;
        Uri u = Uri.parse(url);
        String path = u.getPath();
        return "https".equals(u.getScheme()) && "nk7108715-source.github.io".equals(u.getHost())
            && (u.getPort() == -1 || u.getPort() == 443)
            && u.getUserInfo() == null && (PATH.equals(path) || (PATH + "index.html").equals(path));
    }

    private void receive(String raw) {
        if (destroyed || raw == null || raw.length() > 2048) return;
        try {
            JSONObject message = new JSONObject(raw);
            if ("screen".equals(message.optString("type"))) {
                currentScreen = message.optString("screen");
                bannerWanted = "browse".equals(currentScreen);
                status.setVisibility("study".equals(currentScreen) || "report".equals(currentScreen) ? View.GONE : View.VISIBLE);
                updateBanner();
            } else if ("completed".equals(message.optString("type"))) {
                String event = message.optString("event");
                String kind = message.optString("kind");
                String group = message.optString("group");
                if (event.isEmpty() || event.length() > 100 || group.length() > 800
                        || !completedEvents.add(event)) return;
                handleCompletion(kind, group);
            }
        } catch (Exception ignored) { /* Ignore messages outside the protocol. */ }
    }

    private void loadBanner() {
        if (!sdkReady || destroyed) return;
        banner = new AdView(this);
        banner.setAdUnitId(BANNER);
        int width = Math.max(1, (int) (getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density) - 16);
        banner.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, width));
        TextView label = new TextView(this);
        label.setText("Advertisement · TEST");
        label.setTextSize(10);
        label.setGravity(Gravity.CENTER);
        bannerArea.addView(label);
        bannerArea.addView(banner);
        banner.setAdListener(new AdListener() {
            @Override public void onAdLoaded() { bannerLoaded = true; updateBanner(); }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError error) { bannerLoaded = false; updateBanner(); }
        });
        banner.loadAd(new AdRequest.Builder().build());
    }
    private void updateBanner() {
        boolean visible = resumed && bannerWanted && bannerLoaded && !adShowing;
        bannerArea.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (banner != null) { if (visible) banner.resume(); else banner.pause(); }
    }
    private void loadInterstitial() {
        if (!sdkReady || destroyed || loadingInterstitial || interstitial != null) return;
        loadingInterstitial = true;
        InterstitialAd.load(this, INTERSTITIAL, new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(@NonNull InterstitialAd ad) {
                loadingInterstitial = false;
                if (!destroyed) interstitial = ad;
            }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError error) {
                loadingInterstitial = false;
                interstitial = null;
            }
        });
    }
    private void handleCompletion(String kind, String group) {
        if (!"PYQ".equals(kind) && !"Chapter".equals(kind)) return;
        String day = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(new Date());
        String key = "chapter-" + digest(group);
        boolean seen = day.equals(prefs.getString(key, ""));
        // First completed chapter practice claims the day's one attempt, even with no loaded ad.
        if ("Chapter".equals(kind)) {
            if (seen) return;
            prefs.edit().putString(key, day).apply();
        }
        long elapsed = SystemClock.elapsedRealtime();
        long lastWall = prefs.getLong("last-shown-wall", 0);
        long lastElapsed = prefs.getLong("last-shown-elapsed", 0);
        if (!AdPolicy.frequencyAllowed(System.currentTimeMillis(), lastWall, elapsed, lastElapsed)) return;
        if (interstitial == null) { loadInterstitial(); return; } // Never wait for a late ad.
        web.postDelayed(() -> {
            if (destroyed || !resumed || adShowing || !"report".equals(currentScreen)
                    || !trusted(web.getUrl()) || interstitial == null) return;
            InterstitialAd ad = interstitial;
            interstitial = null;
            adShowing = true;
            updateBanner();
            ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdShowedFullScreenContent() {
                    prefs.edit().putLong("last-shown-wall", System.currentTimeMillis())
                        .putLong("last-shown-elapsed", SystemClock.elapsedRealtime()).apply();
                }
                @Override public void onAdDismissedFullScreenContent() { adShowing = false; updateBanner(); loadInterstitial(); }
                @Override public void onAdFailedToShowFullScreenContent(@NonNull com.google.android.gms.ads.AdError error) {
                    adShowing = false; updateBanner(); loadInterstitial();
                }
            });
            ad.show(this);
        }, 500);
    }
    private static String digest(String value) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : bytes) hex.append(String.format(Locale.ROOT, "%02x", b & 255));
            return hex.toString();
        } catch (Exception impossible) { throw new IllegalStateException(impossible); }
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    @Override public void onBackPressed() {
        if (!trusted(web.getUrl())) { web.loadUrl(START_URL); return; }
        web.evaluateJavascript("(function(){if(typeof focusBack==='function' && ((typeof session!=='undefined'&&session)||(typeof pendingPractice!=='undefined'&&pendingPractice)||(typeof openedMindMap!=='undefined'&&openedMindMap))){focusBack();return true}return false})()", handled -> {
            if (!"true".equals(handled) && !destroyed) new AlertDialog.Builder(this).setMessage("Close NEET UG Pro?")
                .setPositiveButton("Close", (d, w) -> finish()).setNegativeButton("Stay", null).show();
        });
    }
    @Override protected void onResume() {
        super.onResume(); resumed = true;
        if (web != null) {
            web.onResume();
            web.evaluateJavascript("if(typeof resumeTestClock==='function')resumeTestClock()", null);
        }
        updateBanner();
    }
    @Override protected void onPause() {
        resumed = false;
        if (banner != null) banner.pause();
        if (web != null) web.onPause();
        super.onPause();
    }
    @Override public void onConfigurationChanged(android.content.res.Configuration config) {
        super.onConfigurationChanged(config);
        if (banner != null) { banner.destroy(); banner = null; }
        bannerLoaded = false;
        bannerArea.removeAllViews();
        loadBanner();
    }
    @Override protected void onDestroy() {
        destroyed = true;
        if (banner != null) banner.destroy();
        if (web != null) { web.stopLoading(); web.destroy(); }
        super.onDestroy();
    }
}
