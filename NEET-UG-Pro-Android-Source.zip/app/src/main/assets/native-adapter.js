(function () {
  'use strict';
  if (window.__neetNativeAttached || !window.NeetNative ||
      typeof render !== 'function' || typeof completePractice !== 'function') return;
  window.__neetNativeAttached = true;
  const post = data => window.NeetNative.postMessage(JSON.stringify(data));
  function screenState() {
    const studying = (typeof session !== 'undefined' && session) ||
      (typeof pendingPractice !== 'undefined' && pendingPractice) ||
      (typeof openedMindMap !== 'undefined' && openedMindMap);
    const report = typeof session !== 'undefined' && session?.finished && !session.review;
    post({type: 'screen', screen: report ? 'report' : studying ? 'study' :
      ['Home', 'PYQ', 'Chapters'].includes(tab) ? 'browse' : 'other'});
  }
  const baseRender = render;
  render = function () { baseRender(); screenState(); };
  const baseComplete = completePractice;
  completePractice = function (s) {
    const wasFinished = s.finished;
    baseComplete(s);
    if (!wasFinished && s.finished && !s.isPreview) {
      const isPYQ = tab === 'PYQ' && s.items.every(q => q.category === 'PYQ');
      const isChapter = tab === 'Chapters' && s.items.every(q => q.practiceType !== 'ar');
      if (isPYQ || isChapter) {
        post({type: 'completed', event: Date.now().toString(36) + '-' + Math.random().toString(36).slice(2),
          kind: isPYQ ? 'PYQ' : 'Chapter', group: String(s.group || '').slice(0, 800)});
      }
    }
  };
  screenState();
})();
