package com.neetugpro.student;
public final class AdPolicyTest {
    public static void main(String[] args) {
        check(AdPolicy.frequencyAllowed(1000000,0,100,0),"first completion");
        check(!AdPolicy.frequencyAllowed(1100000,1000000,110000,10000),"short gap");
        check(AdPolicy.frequencyAllowed(1120000,1000000,130000,10000),"two minutes");
        check(!AdPolicy.frequencyAllowed(999999,1000000,200000,10000),"wall clock rollback");
        check(!AdPolicy.frequencyAllowed(2000000,1000000,50000,10000),"wall clock forward edit");
        check(AdPolicy.frequencyAllowed(2000000,1000000,5000,10000),"reboot with sufficient wall time");
        System.out.println("PASS: interstitial gap, monotonic guard, rollback and restart.");
    }
    private static void check(boolean value,String label) {if(!value)throw new AssertionError(label);}
}
