const vm = require('node:vm');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const script = fs.readFileSync('app/src/main/assets/native-adapter.js', 'utf8');
const messages = [];
const context = {
  window: {NeetNative: {postMessage: raw => messages.push(JSON.parse(raw))}},
  tab: 'Home', session: null, pendingPractice: null, openedMindMap: null,
  render() {}, completePractice(s) {s.finished = true}, Date, Math
};
vm.createContext(context);
vm.runInContext(script, context);
assert.equal(messages.at(-1).screen, 'browse');
context.session = {finished:false,items:[{category:'PYQ'}],group:'2026 PYQ'};
context.tab = 'PYQ'; context.render(); assert.equal(messages.at(-1).screen, 'study');
context.completePractice(context.session); context.render();
assert.equal(messages.at(-1).screen, 'report');
assert.equal(messages.filter(m=>m.type==='completed').length,1);
assert.equal(messages.find(m=>m.type==='completed').kind,'PYQ');
context.completePractice(context.session);
assert.equal(messages.filter(m=>m.type==='completed').length,1);
context.session.review = {}; context.render(); assert.equal(messages.at(-1).screen,'study');
context.session={finished:false,items:[{category:'Chapterwise'}],group:'Botany · Cell'};
context.tab='Chapters';context.completePractice(context.session);
assert.equal(messages.filter(m=>m.type==='completed').at(-1).kind,'Chapter');
context.session={finished:false,items:[{category:'PYQ'}],isPreview:true};context.completePractice(context.session);
assert.equal(messages.filter(m=>m.type==='completed').length,2);
context.session={finished:false,items:[{category:'PYQ'}]};context.tab='Bookmarks';context.completePractice(context.session);
assert.equal(messages.filter(m=>m.type==='completed').length,2);
context.session=null;context.openedMindMap={};context.render();assert.equal(messages.at(-1).screen,'study');
context.openedMindMap=null;context.pendingPractice={};context.render();assert.equal(messages.at(-1).screen,'study');
vm.runInContext(script,context);assert.equal(messages.filter(m=>m.type==='completed').length,2);
vm.runInNewContext(script,{window:{},render(){},completePractice(){}});
console.log('PASS: browse/study/report state, completion hook, duplicate finish, preview/bookmark exclusion, maps and mode choice, attach once, web-only no-op.');
